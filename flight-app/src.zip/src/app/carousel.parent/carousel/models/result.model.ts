import { Blobs } from './blobs.model';

export class Result {
    Blobs: Blobs;
    MaxResults: string;
    NextMarker: string;
    $: any;
}