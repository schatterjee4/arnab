import { Blob } from './blob.model';

export class Blobs {
    Blob: Blob[]
}