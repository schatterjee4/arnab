export class Blob {
    Url: string;
}