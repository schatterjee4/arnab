import { Result } from './result.model';

export class EnumerationResults {
    EnumerationResults: Result
}